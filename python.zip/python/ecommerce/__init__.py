print("ecommerce initialized")
